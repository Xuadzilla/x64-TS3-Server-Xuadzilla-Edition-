insert into client_properties ( server_id, id, ident, value) 
           values( :server_id:, :client_id*:, :ident*:, :value*:)
 [[[ , (:server_id:, :client_id*:, :ident*:, :value*:) ]]] ;